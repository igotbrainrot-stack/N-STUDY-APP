NSW NURSING STUDY LAB - OFFLINE EDITION 1.5
=========================================

Windows:
  1. Extract all files from the ZIP to a normal folder.
  2. Double-click START_HERE.bat.
  3. Your default browser will open the study program.

Mac / Linux / any desktop:
  Extract the ZIP and open Nursing_Study_Lab.html in a browser.

No installation, internet connection or account is needed to study.
Links to official clinical sources require internet access if opened.
Progress and bookmarks stay locally in your browser. Local-file browser
privacy settings may affect whether they persist between sessions.

Includes 100 questions across 12 modules: 48 foundation questions and
52 applied/advanced questions. New activities include four worked
mathematics exercises, an ordering exercise, two guided three-step
clinical cases, mixed revision, search and review of missed questions.
The Learning studio adds a fictional evidence-to-ISBAR handover workshop,
an adult observation-trend interpretation, and a suggested spaced
revision planner. The planner remains local and is not a competence score.
Clinical reasoning rounds add three advanced adult patient presentations:
possible sepsis with Red Zone deterioration, postoperative opioid-associated
sedation and a quiet/confused patient. Follow three timepoints, choose
interpretations and multiple differential/priorities, then write and compare
an ISBAR. Twelve detailed readings sections support these exercises.
Each module has a source-linked reading guide. There are no grades.

This is an independent learning aid, NOT an official NSW Health training
program or clinical competency assessment. Check the current guidance
and workplace policies before using any information in patient care.
No content has been independently approved by a qualified clinician.
RECHECK NSW medicines legislation and handling directives from 5 Nov 2026.
